<?php
    session_start();
    if (!empty($_SESSION)){
        header("Location: /suivistock/accueil");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="/suivistock/public/template/assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="/suivistock/public/template/assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        Suivi Stock
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="/suivistock/public/template/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="/suivistock/public/template/assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="/suivistock/public/template/assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="main-panel">

<!-- DEBUT FORMULAIRE DE CONNEXION ET D'INSCRIPTION -->
    <div class="row mt-5">
        <div class="col-4 mt-5">
            <h1 class="text-primary text-md-center">CONNECTION</h1>
            <form action="/suivistock/UserController" method="post">
                <div class="form-group">
                    <label for="exampleInputEmail1">Email</label>
                    <input type="text" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Entrez votre Email" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Mot de Passe</label>
                    <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Entrez votre Mot de Passe" required>
                </div>
                <div class="row">
                    <div class="col offset-3">
                        <button type="submit" name="connection" class="btn btn-primary text-center">Se Connecter</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-4 offset-1 mt-5">
            <h1 class="text-primary text-md-center">INSCRIPTION</h1>
            <form action="/suivistock/UserController" method="post">
                <div class="form-group">
                    <label for="exampleInputEmail1">Prenom</label>
                    <input type="text" class="form-control" name="prenom" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Entrez votre Prenom" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Nom</label>
                    <input type="text" class="form-control" name="nom" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Entrez votre Nom" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email</label>
                    <input type="text" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Entrez votre Email" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Mot de Passe</label>
                    <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Entrez votre Mot de Passe" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Etat</label>
                    <select class="form-control" name="etat" id="">
                        <option value="Senegal">Senegal</option>
                        <option value="Mali">Mali</option>
                        <option value="Gambie">Gambie</option>
                        <option value="Guinne">Guinne</option>
                    </select>
                </div>
                <div class="row">
                    <div class="col offset-4">
                        <button type="submit" name="inscription" class="btn btn-primary text-center">S'inscrire</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<!-- FIN FORMULAIRE DE CONNEXION -->

<!--   Core JS Files   -->
<script src="/suivistock/public/template/assets/js/core/jquery.min.js"></script>
<script src="/suivistock/public/template/assets/js/core/popper.min.js"></script>
<script src="/suivistock/public/template/assets/js/core/bootstrap.min.js"></script>
<script src="/suivistock/public/template/assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<!-- Chart JS -->
<script src="/suivistock/public/template/assets/js/plugins/chartjs.min.js"></script>
<!--  Notifications Plugin    -->
<script src="/suivistock/public/template/assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="/suivistock/public/template/assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
<script src="/suivistock/public/template/assets/demo/demo.js"></script>
<script>
    $(document).ready(function() {
        // Javascript method's body can be found in assets/assets-for-demo/js/demo.js
        demo.initChartsPages();
    });
</script>
</body>

</html>