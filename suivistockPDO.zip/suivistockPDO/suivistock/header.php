<?php global $isActive; ?>
<?php
    session_start();
    if (empty($_SESSION)){
        header("Location: /suivistock/");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="/suivistock/public/template/assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="/suivistock/public/template/assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        SUIVI STOCK
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="/suivistock/public/template/assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="/suivistock/public/template/assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="/suivistock/public/template/assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
<div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
        <div class="logo">
            <a href="https://www.creative-tim.com" class="simple-text logo-mini">
                <div class="logo-image-small">
                    <img src="/GestionPointageISI/public/template/assets/img/logo-small.png">
                </div>
                <!-- <p>CT</p> -->
            </a>
            <a href="https://www.creative-tim.com" class="simple-text logo-normal">
                Suivi de Produit
                <!-- <div class="logo-image-big">
                  <img src="../assets/img/logo-big.png">
                </div> -->
            </a>
        </div>
        <div class="sidebar-wrapper">
            <ul class="nav">
                <li class="<?php if ($isActive == "dashbord"){ ?> active <?php } ?>">
                    <a href="/suivistock/accueil">
                        <i class="nc-icon nc-bank"></i>
                        <p>Tableau de Bord</p>
                    </a>
                </li>
                <li class="dropdown <?php if ($isActive == "produit"){ ?> active <?php } ?>">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" id="dropdownMenuButton" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                        <i class="nc-icon nc-briefcase-24"></i>
                        Produit&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </a>
                    <div class="dropdown-menu ml-5" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="/suivistock/produit/add"><i style="font-size: 20px; padding-bottom: 2px;" class="nc-icon nc-simple-add"></i>Ajouter un Produit</a>
                        <a class="dropdown-item" href="/suivistock/produit/list"><i style="font-size: 20px" class="nc-icon nc-vector"></i>Gerer les Produits</a>
                    </div>
                </li>
                <li class="active-pro">
                    <a href="/suivistock/UserController?btnDeconnect=1">
                        <i class="nc-icon nc-spaceship"></i>
                        <p>Se Deconnecter</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>