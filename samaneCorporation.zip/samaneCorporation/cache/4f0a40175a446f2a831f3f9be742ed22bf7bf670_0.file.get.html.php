<?php
/* Smarty version 3.1.30, created on 2021-02-16 00:48:22
  from "/Applications/XAMPP/xamppfiles/htdocs/SamaneMVC/geolocalisationSite/src/view/ville/get.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_602b08463fc4b4_68809866',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4f0a40175a446f2a831f3f9be742ed22bf7bf670' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/SamaneMVC/geolocalisationSite/src/view/ville/get.html',
      1 => 1613432894,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_602b08463fc4b4_68809866 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>GeoLocalisation</title>
</head>
<body>
    <h>La ville recuperer est: <?php echo $_smarty_tpl->tpl_vars['idVille']->value;?>
</h>
</body>
</html><?php }
}
