<?php
/* Smarty version 3.1.30, created on 2021-02-17 16:43:50
  from "/Applications/XAMPP/xamppfiles/htdocs/SamaneMVC/samaneCorporation/src/view/welcome/index.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_602d39b69f4d44_33670051',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7f7f2c6fb7d10e689c9c62ea584f01fd4e027548' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/SamaneMVC/samaneCorporation/src/view/welcome/index.html',
      1 => 1613576630,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_602d39b69f4d44_33670051 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>SamaneCorp | Accueil</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/template/plugins/fontawesome-free/css/all.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
	<!-- icheck bootstrap -->
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/template/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
	<!-- Theme style -->
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/template/dist/css/adminlte.min.css">
	<!-- Google Font: Source Sans Pro -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition login-page">
<div class="row mt-3">
	<div class="col-7 offset-1">
		<div class="container">
			<div class="card">
				<div class="card-header">
					<h1><b>Samame</b>Corp</h1>
					<p style="display: inline;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nous vous proposons un systeme qui vous permet de voir nos offres d'emplois et de poster votre CV.</p>
				</div>
				<div class="card-body">
					<div class="card-img">
						<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/samanemvc.jpg" alt="">
					</div>
					<div class="card-dark">
						<p>
							L’objectif du framework est d’aider les développeurs à avoir un modèle simple d’utilisation, très structuré et respectant toutes les conventions du langage PHP. Toute la communauté web est invitée à l’utiliser et à faire des retours d’expériences dans le but de le perfectionner.
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-4 mt-4">
		<div class="container">
			<div class="login-box">
				<div class="login-logo">
					<a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/template/index2.html"><b>Samame</b>Corp</a>
				</div>
				<!-- /.login-logo -->
				<div class="card">
					<div class="card-body login-card-body">
						<p class="login-box-msg">Connectez-vous pour voir nos Offres</p>

						<form action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Welcome/login" method="post">
							<div class="input-group mb-3">
								<input type="email" class="form-control" name="email" placeholder="Email" required>
								<div class="input-group-append">
									<div class="input-group-text">
										<span class="fas fa-envelope"></span>
									</div>
								</div>
							</div>
							<div class="input-group mb-3">
								<input type="password" class="form-control" name="password" placeholder="Mot de Passe" required>
								<div class="input-group-append">
									<div class="input-group-text">
										<span class="fas fa-lock"></span>
									</div>
								</div>
							</div>
							<div class="row">
								<!-- /.col -->
								<div class="col-6 offset-3">
									<button type="submit" name="connecter" class="btn btn-primary btn-block">Se Connecter</button>
								</div>
								<!-- /.col -->
							</div>
						</form>
						<p class="mb-0 text-danger" <?php if (!isset($_smarty_tpl->tpl_vars['errorLogin']->value)) {?> hidden <?php }?>><?php echo $_smarty_tpl->tpl_vars['errorLogin']->value;?>
</p>
					</div>
					<!-- /.login-card-body -->
				</div>
			</div>
			<!-- /.login-box -->

			<div class="register-box">
				<div class="card">
					<div class="card-body register-card-body">
						<p class="login-box-msg">S'inscrire pour profiter de nos Offres</p>

						<form action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Welcome/register" method="post">
							<div class="input-group mb-3">
								<input type="text" class="form-control" name="nomcomplet" placeholder="Nom Complet" required>
								<div class="input-group-append">
									<div class="input-group-text">
										<span class="fas fa-user"></span>
									</div>
								</div>
							</div>
							<div class="input-group mb-3">
								<input type="email" class="form-control" name="email" placeholder="Email" required>
								<div class="input-group-append">
									<div class="input-group-text">
										<span class="fas fa-envelope"></span>
									</div>
								</div>
							</div>
							<div class="input-group mb-3">
								<input type="password" class="form-control" name="password" placeholder="Mot de Passe" required>
								<div class="input-group-append">
									<div class="input-group-text">
										<span class="fas fa-lock"></span>
									</div>
								</div>
							</div>
							<div class="input-group mb-3">
								<input type="password" class="form-control" name="passwordconfirm" placeholder="Confirmer le Mot de Passe" required>
								<div class="input-group-append">
									<div class="input-group-text">
										<span class="fas fa-lock"></span>
									</div>
								</div>
							</div>
							<div class="row">
								<!-- /.col -->
								<div class="col-6 offset-3">
									<button type="submit" class="btn btn-primary btn-block">S'inscrire</button>
								</div>
								<!-- /.col -->
							</div>
						</form>
						<p class="mb-0 text-danger" <?php if (!isset($_smarty_tpl->tpl_vars['errorRegister']->value)) {?> hidden <?php }?>><?php echo $_smarty_tpl->tpl_vars['errorRegister']->value;?>
</p>
					</div>
					<!-- /.form-box -->
				</div><!-- /.card -->
			</div>
			<!-- /.register-box -->
		</div>
	</div>
</div>

<!-- jQuery -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/template/plugins/jquery/jquery.min.js"><?php echo '</script'; ?>
>
<!-- Bootstrap 4 -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/template/plugins/bootstrap/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
<!-- AdminLTE App -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/template/dist/js/adminlte.min.js"><?php echo '</script'; ?>
>

</body>
</html>
<?php }
}
