<?php
/* Smarty version 3.1.30, created on 2021-02-16 00:46:42
  from "/Applications/XAMPP/xamppfiles/htdocs/SamaneMVC/geolocalisationSite/src/view/ville/localiser.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_602b07e2468c52_47009694',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cea98854d42c404f44533a5ec5201f47d0f88d35' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/SamaneMVC/geolocalisationSite/src/view/ville/localiser.html',
      1 => 1613432800,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_602b07e2468c52_47009694 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>GeoLocalisation</title>
</head>
<body>
    <h1>La Ville de <?php echo $_smarty_tpl->tpl_vars['nomVille']->value;?>
 est charger!</h1>
    <ul>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['villes']->value, 'ville');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['ville']->value) {
?>
            <li><?php echo $_smarty_tpl->tpl_vars['ville']->value;?>
</li>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

    </ul>
</body>
</html><?php }
}
