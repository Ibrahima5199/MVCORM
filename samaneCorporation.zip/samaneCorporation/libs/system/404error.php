<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
        <title>404 Error Not Found</title>
        <link type="text/css" rel="stylesheet" href="<?php echo base_url();?>public/css/bootstrap.min.css"/>
    <style>
        #design_error{
            font-size : 22px;
            color : red;
            margin-top: 500px;
            margin: auto;
        }
    </style>
</head>
<body>
<div>
    <div class="alert alert-danger" style="font-size:18px; text-align:justify;">
        Désolé, cette page n'est pas disponible
    </div>
</div>
</body>
</html>