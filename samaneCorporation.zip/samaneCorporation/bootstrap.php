<?php
// bootstrap.php
use Doctrine\ORM\Tools\Setup;
use Doctrine\ORM\EntityManager;

require_once "vendor/autoload.php";
require "config/database.php";

$cache = new \Doctrine\Common\Cache\ArrayCache;

// Create a simple "default" Doctrine ORM configuration for Annotations
$isDevMode = true;
$proxyDir = null;
$cache = null;
$useSimpleAnnotationReader = false;
$config = Setup::createAnnotationMetadataConfiguration(array(__DIR__."/src/entities/"), $isDevMode, $proxyDir, $cache, $useSimpleAnnotationReader);

//$config->setMetadataCacheImpl($cache);
//$config->setQueryCacheImpl($cache);
$config->setProxyDir(__DIR__.'/cache/proxies/');
$config->setProxyNamespace('Samane\Proxies');

// obtaining the entity manager
$entityManager = EntityManager::create($orm, $config);