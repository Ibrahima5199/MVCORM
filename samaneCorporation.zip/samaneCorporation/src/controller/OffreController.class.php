<?php
use libs\system\Controller;
use src\model\OffreRepository;

class OffreController extends Controller{

    public function __construct()
    {
        parent::__construct();
    }

    public function insert(){
        $offreDb = new OffreRepository();
        extract($_POST);
        $offre = new Offre();
        $offre->setTitre($titre);
        $offre->setDescription($description);
        $offre->setType($type);
//        $offre->setDate($datePublication);
        $offre->setDate(new DateTime($datePublication));
        $offre->setCategorie($offreDb->getCategorie($idCat));
        $offreDb->add($offre);
        $data["result"] = "L'offre a etait enregistrer avec succes!";
        return $this->view->load("recruteur/poster", $data);
    }

    public function delete($id)
    {
        $offreDb = new OffreRepository();
        $offreDb->delete($id);
        $data["resultDelete"] = "L'offre a etait supprimer avec succes!";
        $data["listeOffre"] = $offreDb->getAll();
        return $this->view->load("recruteur/liste", $data);
    }

    public function edit($id)
    {
        $categorieDb = new CategorieRepository();
        $offreDb = new OffreRepository();
        $data["offre"] = $offreDb->get($id);
        $data["listeCat"] = $categorieDb ->getAll();
        return $this->view->load("recruteur/edit", $data);
    }

    public function update(){
        $offreDb = new OffreRepository();
        $categorieDb = new CategorieRepository();
        extract($_POST);
        $offre = new Offre();
        $offre->setId($id);
        $offre->setTitre($titre);
        $offre->setDescription($description);
        $offre->setType($type);
        $offre->setDate(new DateTime($datePublication));
        $offre->setCategorie($offreDb->getCategorie($idCat));
        $offreDb->update($offre);
        $data["result"] = "L'offre a etait modifier avec succes!";
        $data["offre"] = $offreDb->get($id);
        $data["listeCat"] = $categorieDb ->getAll();
        return $this->view->load("recruteur/edit", $data);
    }
}