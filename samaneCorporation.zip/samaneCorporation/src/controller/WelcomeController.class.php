<?php
/*==================================================
MODELE MVC DEVELOPPE PAR Ngor SECK
ngorsecka@gmail.com
(+221) 77 - 433 - 97 - 16
PERFECTIONNEZ CE MODELE ET FAITES MOI UN RETOUR
POUR TOUTE MODIFICATION VISANT A L'AMELIORER.
VOUS ETES LIBRE DE TOUTE UTILISATION.
===================================================*/
use libs\system\Controller;
use src\model\UserRepository;

class WelcomeController extends Controller{

    public function __construct(){
        parent::__construct();
    }
    /** 
     * use: localhost/projectName/Welcome/
     */
    public function index(){  
        return $this->view->load("welcome/index");   
    }

    public function login()
    {
        extract($_POST);
        if ($email == "recruteur@samane.com" && $password == "recruteur123"){
            $this->view->redirect("Recruteur/index");
        }else{
            $userDb = new UserRepository();
            $user = $userDb->getUser($email, $password);

            if(!empty($user)){
                session_start();
                $_SESSION['id'] = $user->getId();
                $_SESSION['nomcomplet'] = $user->getFullname();
                $_SESSION['email'] = $user->getEmail();
                $this->view->redirect("User/index");
            }else{
                $data['errorLogin'] = "L'email ou le mot de passe est incorrect!";
                $this->view->load("welcome/index", $data);
            }
        }
    }

    public function register()
    {
        extract($_POST);
        if ($password != $passwordconfirm){
            $data['errorRegister'] = "Les mot de passe ne corresponde pas!";
            $this->view->load("welcome/index", $data);
        }else{
            $user = new User();
            $user->setFullname($nomcomplet);
            $user->setEmail($email);
            $user->setPassword($password);
            $userDb = new UserRepository();

            $userDb->add($user);

            $data['errorRegister'] = "<span class='text-primary'>L'utilisateur a etait enregister avec success!</span>";
            $this->view->load("welcome/index", $data);
        }
    }
}
?>