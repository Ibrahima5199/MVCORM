<?php

use libs\system\Controller;
use src\model\PaysRepository;
use src\model\VilleRepository;

class VilleController extends Controller{
    public function __construct()
    {
        parent::__construct();
    }

    public function liste(){
        $villeDb = new VilleRepository();
        $paysDb = new PaysRepository();
        $data["listeVilles"] = $villeDb->getAll();
        $data["listePays"] = $paysDb->getAll();
        return $this->view->load("ville/liste", $data);
    }

    public function edit($id)
    {
        $paysDb = new PaysRepository();
        $villeDb = new VilleRepository();
        $data["ville"] = $villeDb->get($id);
        $data["listeVilles"] = $villeDb->getAll();
        $data["listePays"] = $paysDb ->getAll();
        return $this->view->load("ville/edit", $data);
    }

    public function delete($id)
    {
        $villeDb = new VilleRepository();
        $villeDb->delete($id);
        return $this->liste();
    }

    public function update(){
        $villeDb = new VilleRepository();
        extract($_POST);
        $ville = new Ville();
        $ville->setId($id);
        $ville->setNom($nom);
        $ville->setLatitude($latitude);
        $ville->setLongitude($longitude);
        $ville->setPays($villeDb->getPays($idpays));

        $villeDb->update($ville);

        return $this->liste();
    }

    public function insert(){
        $villeDb = new VilleRepository();
        extract($_POST);
        $ville = new Ville();
        $ville->setNom($nom);
        $ville->setLatitude($latitude);
        $ville->setLongitude($longitude);
        $ville->setPays($villeDb->getPays($idpays));

        $villeDb->add($ville);

        return $this->liste();
    }
}