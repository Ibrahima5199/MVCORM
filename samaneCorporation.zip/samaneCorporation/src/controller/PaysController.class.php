<?php

use libs\system\Controller;
use src\model\PaysRepository;

class PaysController extends Controller{
    public function __construct()
    {
        parent::__construct();
    }

    public function liste(){
        $paysDb = new PaysRepository();
        $data["listePays"] = $paysDb->getAll();
        return $this->view->load("pays/liste", $data);
    }

    public function edit($id)
    {
        $paysDb = new PaysRepository();
        $data["pays"] = $paysDb->get($id);
        $data["listePays"] = $paysDb->getAll();
        return $this->view->load("pays/edit", $data);
    }

    public function delete($id)
    {
        $paysDb = new PaysRepository();
        $paysDb->delete($id);
        return $this->liste();
    }

    public function update(){
        extract($_POST);
        $pays = new Pays();
        $pays->setId($id);
        $pays->setNom($nom);
        $pays->setLatitude($latitude);
        $pays->setLongitude($longitude);

        $paysDb = new PaysRepository();
        $paysDb->update($pays);

        return $this->liste();
    }

    public function insert(){
        extract($_POST);
        $pays = new Pays();
        $pays->setNom($nom);
        $pays->setLatitude($latitude);
        $pays->setLongitude($longitude);

        $paysDb = new PaysRepository();

        $paysDb->add($pays);

        return $this->liste();
    }
}