<?php

use libs\system\Controller;
use src\model\OffreRepository;

class RecruteurController extends Controller{
    public function __construct()
    {
        parent::__construct();
    }

    public function index(){
        $offreDb = new OffreRepository();
        $categorieDb = new CategorieRepository();
        $data["nbOffre"] = count($offreDb->getAll());
        $data["nbCat"] = count($categorieDb->getAll());
        return $this->view->load("recruteur/index", $data);
    }

    public function poster(){
        $categorieDb = new CategorieRepository();
        $data["listeCat"] = $categorieDb->getAll();
        return $this->view->load("recruteur/poster", $data);
    }

    public function liste(){
        $offreDb = new OffreRepository();
        $data["listeOffre"] = $offreDb->getAll();
        return $this->view->load("recruteur/liste", $data);
    }
}