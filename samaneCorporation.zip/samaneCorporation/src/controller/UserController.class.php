<?php

use libs\system\Controller;
use src\model\OffreRepository;
use src\model\UserRepository;

class UserController extends Controller{
    public function __construct()
    {
        parent::__construct();

    }

    public function index(){
        $offreDb = new OffreRepository();
        $categorieDb = new CategorieRepository();
        $data["nbOffre"] = count($offreDb->getAll());
        $data["nbCat"] = count($categorieDb->getAll());
        return $this->view->load("user/index", $data);
    }

    public function cv(){
        session_start();
        $userDb = new UserRepository();
        $data['user'] = $userDb->get($_SESSION['id']);
        return $this->view->load("user/cv", $data);
    }

    public function editCv(){
        session_start();
        extract($_POST);
        $userDb = new UserRepository();
        $user = $userDb->get($_SESSION['id']);
        $user->setAdresse($adresse);
        $user->setNumero($numero);
        $user->setCompetences($competences);
        $user->setFormations($formations);
        $user->setInterret($interet);
        $user->setSkills($skills);
        $userDb->updateCv($user);
        $data['user'] = $user;
        $data["result"] = "Votre CV a etait Mis a Jour avec Succes!";
        return $this->view->load("user/cv", $data);
    }

    public function favoris(){
        session_start();
        $userDb = new UserRepository();
        $categorisDb = new CategorieRepository();
        $data['user'] = $userDb->get($_SESSION['id']);
        $data['listCat'] = $categorisDb->getAll();
        return $this->view->load("user/favoris", $data);
    }

    public function editFavoris(){
        session_start();
        extract($_POST);
        $userDb = new UserRepository();
        $categorisDb = new CategorieRepository();
        $user = $userDb->get($_SESSION['id']);
//        var_dump($favoris);
        $user->setFavoris($favoris);
        $userDb->updateFavoris($user);
        $data['user'] = $userDb->get($_SESSION['id']);
        $data["result"] = "Vos Favoris ont etait Mis a Jour avec Succes!";
        $data['listCat'] = $categorisDb->getAll();
        return $this->view->load("user/favoris", $data);
    }

    public function rechercher()
    {
        extract($_POST);
        $offreDb = new OffreRepository();
//        $data['listeOffre'] = $offreDb->getAllByValue($valeurRecherche);
        $data['listeOffre'] = $offreDb->getAll();
        return $this->view->load("user/offersRecherche", $data);
    }

    public function offersRecherche()
    {
        $offreDb = new OffreRepository();
        $data['listeOffre'] = $offreDb->getAll();
        return $this->view->load("user/offersRecherche", $data);
    }

    public function offersFavoris()
    {
        session_start();
        $offreDb = new OffreRepository();
        $userDb = new UserRepository();
        $user = $userDb->get($_SESSION['id']);
        $data['listeOffre'] = $offreDb->getAllByFavoris($user->getFavoris());
        return $this->view->load("user/offersFavoris", $data);
    }

    public function detail($id)
    {
        $offreDb = new OffreRepository();
        $categorisDb = new CategorieRepository();
        $data['offre'] = $offreDb->get($id);
        $data["listeCat"] = $categorisDb->getAll();
        return $this->view->load("user/detail", $data);
    }

    public function postuler($id)
    {
        session_start();
        $offreDb = new OffreRepository();
        $categorisDb = new CategorieRepository();
        $userDb = new UserRepository();
        $offre = $offreDb->get($id);
        $userDb->addOffreForUser($_SESSION['id'], $offre);
        $data['offre'] = $offre;
        $data["listeCat"] = $categorisDb->getAll();
        $data["result"] = "Vous avez postuler a cette Offre avec Succes!";
        return $this->view->load("user/detail", $data);
    }
}