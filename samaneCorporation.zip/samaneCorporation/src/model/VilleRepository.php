<?php
namespace src\model;

use libs\system\Model;

class VilleRepository extends Model
{

    /**
     * Methods with DQL (Doctrine Query Language)
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function getAll()
    {
        return $this->db->getRepository("Ville")->findAll();
    }

    public function get($id)
    {
        return $this->db->getRepository("Ville")->find(array("id"=>$id));
    }

    public function getPays($id)
    {
        return $this->db->getRepository("Pays")->find(array("id"=>$id));
    }

//    public function add(\Pays $pays)
    public function add($ville)
    {
        $this->db->persist($ville);
        $this->db->flush();
    }

    public function update($ville)
    {
        $v = $this->get($ville->getId());
        $v->setNom($ville->getNom());
        $v->setLatitude($ville->getLatitude());
        $v->setLongitude($ville->getLongitude());
        $this->db->flush();
    }

    public function delete($id)
    {
        $v = $this->get($id);
        $this->db->remove($v);
        $this->db->flush();
    }
}