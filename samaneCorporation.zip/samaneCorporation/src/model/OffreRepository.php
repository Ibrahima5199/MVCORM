<?php

namespace src\model;

use libs\system\Model;

class OffreRepository extends Model
{

    /**
     * Methods with DQL (Doctrine Query Language)
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function getAll()
    {
        return $this->db->getRepository("Offre")->findAll();
    }

    public function getAllByFavoris($favoris)
    {
        $categoris = $this->db->getRepository("Categorie")->findOneBy(array("nom"=>$favoris));
        $offres =  $this->db->getRepository("Offre")->findBy(["categorie"=>$categoris]);
        var_dump($offres);var_dump($offres);var_dump($this->get(1)->getCategorie());
        return $offres;
    }

    public function get($id)
    {
        return $this->db->getRepository("Offre")->find(array("id"=>$id));
    }

    public function getCategorie($id)
    {
        return $this->db->getRepository("Categorie")->find(array("id"=>$id));
    }

    public function add($offre)
    {
        $this->db->persist($offre);
        $this->db->flush();
    }

    public function update($offre)
    {
        $offer = $this->get($offre->getId());
        $offer->setTitre($offre->getTitre());
        $offer->setDescription($offre->getDescription());
        $offer->setType($offre->getType());
        $offer->setDate($offre->getDate());
        $offer->setCategorie($offre->getCategorie());
        $this->db->flush();
    }

    public function delete($id)
    {
        $offre = $this->get($id);
        $this->db->remove($offre);
        $this->db->flush();
    }
}