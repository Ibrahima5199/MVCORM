<?php
namespace src\model;

use libs\system\Model;

class PaysRepository extends Model
{

    /**
     * Methods with DQL (Doctrine Query Language)
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function getAll()
    {
        return $this->db->getRepository("Pays")->findAll();
    }

    public function get($id)
    {
        return $this->db->getRepository("Pays")->find(array("id"=>$id));
    }

//    public function add(\Pays $pays)
    public function add($pays)
    {
        $this->db->persist($pays);
        $this->db->flush();
    }

    public function update($pays)
    {
        $p = $this->get($pays->getId());
        $p->setNom($pays->getNom());
        $p->setLatitude($pays->getLatitude());
        $p->setLongitude($pays->getLongitude());
        $this->db->flush();
    }

    public function delete($id)
    {
        $p = $this->get($id);
        $this->db->remove($p);
        $this->db->flush();
    }
}