<?php

use libs\system\Model;

class CategorieRepository extends Model
{

    /**
     * Methods with DQL (Doctrine Query Language)
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function getAll()
    {
        return $this->db->getRepository("Categorie")->findAll();
    }

    public function get($id)
    {
        return $this->db->getRepository("Categorie")->find(array("id"=>$id));
    }
}