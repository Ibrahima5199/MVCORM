<?php
namespace src\model;

use libs\system\Model;

class UserRepository extends Model
{

    /**
     * Methods with DQL (Doctrine Query Language)
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function getAll()
    {
        return $this->db->getRepository("User")->findAll();
    }

    public function get($id)
    {
        return $this->db->getRepository("User")->find(array("id"=>$id));
    }

    public function getUser($email, $password)
    {
        return $this->db->getRepository("User")->findOneBy(["email"=>$email]);
    }

//    public function add(\Pays $pays)
    public function add($user)
    {
        $this->db->persist($user);
        $this->db->flush();
    }

    public function updateCv($user)
    {
        $u = $this->get($user->getId());
        $u->setAdresse($user->getAdresse());
        $u->setNumero($user->getNumero());
        $u->setCompetences($user->getCompetences());
        $u->setFormations($user->getFormations());
        $u->setInterret($user->getInterret());
        $u->setSkills($user->getSkills());
        $this->db->flush();
    }

    public function updateFavoris($user)
    {
        $u = $this->get($user->getId());
        $u->setFavoris($user->getFavoris());
        $this->db->flush();
    }

//    public function addOffreForUser($userId, $offre)
//    {
//        $user = $this->get($userId);
//        $user->addOffre($offre);
//        $this->db->flush();
//    }
//
//    public function delete($id)
//    {
//        $p = $this->get($id);
//        $this->db->remove($p);
//        $this->db->flush();
//    }
}